^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package micro_ros_raspberrypicosdk
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.0.0 (2024-06-03)
------------------
* CI typo
* micro-ROS rolling Library auto-update 03-06-2024 09:25 (`#1192 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1192>`_)
  Co-authored-by: pablogs9 <7647884+pablogs9@users.noreply.github.com>
* Bump CI Checkout
* micro-ROS rolling Library auto-update 28-05-2024 06:10 (`#1187 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1187>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 27-05-2024 06:11 (`#1186 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1186>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-05-2024 06:10 (`#1183 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1183>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-05-2024 06:10 (`#1182 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1182>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 16-05-2024 06:08 (`#1178 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1178>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-05-2024 06:09 (`#1175 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1175>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-05-2024 06:10 (`#1173 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1173>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 10-05-2024 06:09 (`#1170 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1170>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-05-2024 06:09 (`#1168 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1168>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-05-2024 06:09 (`#1159 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1159>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 30-04-2024 06:09 (`#1158 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1158>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 29-04-2024 06:09 (`#1155 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1155>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 27-04-2024 06:08 (`#1154 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1154>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 25-04-2024 06:09 (`#1153 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1153>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 24-04-2024 06:10 (`#1150 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1150>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 17-04-2024 06:10 (`#1146 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1146>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 16-04-2024 06:09 (`#1145 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1145>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-04-2024 06:09 (`#1141 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1141>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 12-04-2024 06:09 (`#1140 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1140>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-04-2024 06:09 (`#1139 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1139>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 10-04-2024 06:09 (`#1138 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1138>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-04-2024 06:08 (`#1137 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1137>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 08-04-2024 06:09 (`#1136 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1136>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 06-04-2024 06:08 (`#1133 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1133>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 05-04-2024 06:08 (`#1132 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1132>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 04-04-2024 06:08 (`#1131 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1131>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 03-04-2024 06:08 (`#1130 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1130>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-04-2024 06:08 (`#1127 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1127>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 01-04-2024 06:09 (`#1126 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1126>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 30-03-2024 06:07 (`#1125 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1125>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-03-2024 06:08 (`#1120 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1120>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-03-2024 06:08 (`#1118 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1118>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 20-03-2024 06:08 (`#1116 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1116>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 19-03-2024 06:08 (`#1115 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1115>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 18-03-2024 06:09 (`#1113 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1113>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-03-2024 06:08 (`#1111 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1111>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-03-2024 06:08 (`#1108 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1108>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 12-03-2024 06:08 (`#1106 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1106>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 08-03-2024 06:08 (`#1104 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1104>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-03-2024 06:09 (`#1103 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1103>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 06-03-2024 06:09 (`#1102 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1102>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 04-03-2024 06:54 (`#1098 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1098>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-03-2024 06:08 (`#1097 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1097>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 01-03-2024 06:09 (`#1096 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1096>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 29-02-2024 06:09 (`#1095 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1095>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 28-02-2024 06:08 (`#1094 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1094>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 27-02-2024 06:08 (`#1093 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1093>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 23-02-2024 06:09 (`#1091 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1091>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-02-2024 06:08 (`#1090 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1090>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-02-2024 06:08 (`#1089 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1089>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 20-02-2024 06:08 (`#1088 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1088>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 17-02-2024 06:07 (`#1086 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1086>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-02-2024 06:08 (`#1083 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1083>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 13-02-2024 06:09 (`#1080 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1080>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-02-2024 06:08 (`#1078 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1078>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 08-02-2024 06:09 (`#1076 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1076>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-02-2024 06:08 (`#1075 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1075>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 06-02-2024 06:08 (`#1074 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1074>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 03-02-2024 06:07 (`#1073 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1073>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-02-2024 06:08 (`#1072 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1072>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 01-02-2024 06:08 (`#1069 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1069>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 31-01-2024 06:08 (`#1068 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1068>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 30-01-2024 06:08 (`#1066 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1066>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 28-01-2024 06:07 (`#1065 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1065>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 26-01-2024 06:08 (`#1064 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1064>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 25-01-2024 06:09 (`#1063 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1063>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 24-01-2024 06:09 (`#1061 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1061>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 20-01-2024 06:07 (`#1058 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1058>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 19-01-2024 06:09 (`#1056 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1056>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 13-01-2024 06:07 (`#1055 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1055>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-01-2024 06:09 (`#1054 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1054>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 10-01-2024 06:08 (`#1053 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1053>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-01-2024 06:09 (`#1052 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1052>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 06-01-2024 06:07 (`#1051 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1051>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* Fix stdio init (`#1048 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1048>`_)
* micro-ROS rolling Library auto-update 03-01-2024 06:08 (`#1044 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1044>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-12-2023 06:08 (`#1042 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1042>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-12-2023 06:08 (`#1040 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1040>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-12-2023 06:09 (`#1037 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1037>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 05-12-2023 06:09 (`#1034 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1034>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-12-2023 06:08 (`#1033 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1033>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 01-12-2023 06:10 (`#1031 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1031>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 30-11-2023 06:09 (`#1029 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1029>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 29-11-2023 06:08 (`#1027 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1027>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 28-11-2023 06:09 (`#1026 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1026>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 27-11-2023 06:09 (`#1025 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1025>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-11-2023 06:09 (`#1023 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1023>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-11-2023 06:08 (`#1020 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1020>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 18-11-2023 06:07 (`#1019 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1019>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 17-11-2023 06:09 (`#1017 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1017>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 16-11-2023 06:08 (`#1015 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1015>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-11-2023 06:08 (`#1012 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1012>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-11-2023 06:07 (`#1010 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1010>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-11-2023 06:08 (`#1007 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1007>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS Library auto-update 08-11-2023 06:08 (`#1006 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1006>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS Library auto-update 07-11-2023 06:08 (`#1005 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1005>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS Library auto-update 06-11-2023 06:09 (`#1004 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1004>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS Library auto-update 03-11-2023 06:08 (`#1003 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1003>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 01-11-2023 06:08 (`#1002 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1002>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 31-10-2023 06:08 (`#1001 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1001>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 25-10-2023 06:08 (`#1000 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1000>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 18-10-2023 06:08 (`#998 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/998>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 13-10-2023 06:09 (`#997 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/997>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 12-10-2023 06:08 (`#996 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/996>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-10-2023 06:09 (`#995 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/995>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 10-10-2023 06:08 (`#994 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/994>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-10-2023 06:07 (`#992 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/992>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 05-10-2023 06:14 (`#991 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/991>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 04-10-2023 06:08 (`#990 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/990>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-10-2023 06:08 (`#988 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/988>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 30-09-2023 06:07 (`#986 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/986>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 29-09-2023 06:08 (`#985 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/985>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 23-09-2023 06:07 (`#984 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/984>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-09-2023 06:08 (`#983 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/983>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-09-2023 06:08 (`#982 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/982>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 18-09-2023 06:08 (`#979 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/979>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-09-2023 06:08 (`#978 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/978>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-09-2023 06:08 (`#976 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/976>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 13-09-2023 06:08 (`#975 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/975>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 12-09-2023 06:08 (`#974 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/974>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-09-2023 06:08 (`#973 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/973>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 09-09-2023 06:06 (`#971 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/971>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 08-09-2023 06:07 (`#969 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/969>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-09-2023 06:07 (`#968 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/968>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 06-09-2023 06:08 (`#967 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/967>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 05-09-2023 06:07 (`#962 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/962>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 02-09-2023 06:06 (`#954 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/954>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 16-08-2023 06:07 (`#953 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/953>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-08-2023 06:07 (`#952 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/952>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 11-08-2023 06:07 (`#950 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/950>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-08-2023 06:08 (`#949 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/949>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 05-08-2023 06:07 (`#946 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/946>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 04-08-2023 06:08 (`#944 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/944>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 26-07-2023 06:08 (`#936 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/936>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 18-07-2023 06:08 (`#933 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/933>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-07-2023 06:08 (`#930 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/930>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-07-2023 06:09 (`#926 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/926>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 07-07-2023 06:09 (`#924 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/924>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 28-06-2023 06:09 (`#922 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/922>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 24-06-2023 06:08 (`#920 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/920>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 22-06-2023 06:08 (`#918 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/918>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 21-06-2023 06:08 (`#915 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/915>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 17-06-2023 06:07 (`#912 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/912>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 16-06-2023 06:08 (`#911 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/911>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 15-06-2023 06:08 (`#908 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/908>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* micro-ROS rolling Library auto-update 14-06-2023 06:08 (`#905 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/905>`_)
  Co-authored-by: pablogs9 <pablogs9@users.noreply.github.com>
* Contributors: Pablo Garrido, github-actions[bot]

5.0.0 (2023-06-12)
------------------
* micro-ROS rolling Library auto-update 12-06-2023 06:08 (`#902 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/902>`_)
* Deprecate foxy (`#900 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/900>`_)
* micro-ROS rolling Library auto-update 06-06-2023 06:08 (`#896 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/896>`_)
* micro-ROS rolling Library auto-update 05-06-2023 06:08 (`#895 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/895>`_)
* micro-ROS rolling Library auto-update 03-06-2023 06:07 (`#894 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/894>`_)
* micro-ROS rolling Library auto-update 25-05-2023 06:08 (`#888 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/888>`_)
* micro-ROS rolling Library auto-update 17-05-2023 06:08 (`#885 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/885>`_)
* micro-ROS rolling Library auto-update 16-05-2023 07:48 (`#882 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/882>`_)
* Deprecate galactic and Sort output of library_generation (backport `#879 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/879>`_) (`#880 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/880>`_)
* micro-ROS rolling Library auto-update 18-04-2023 06:08 (`#870 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/870>`_)
* micro-ROS rolling Library auto-update 15-04-2023 06:07 (`#869 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/869>`_)
* micro-ROS rolling Library auto-update 14-04-2023 06:08 (`#868 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/868>`_)
* micro-ROS rolling Library auto-update 13-04-2023 06:08 (`#867 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/867>`_)
* micro-ROS rolling Library auto-update 12-04-2023 06:08 (`#866 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/866>`_)
* micro-ROS rolling Library auto-update 11-04-2023 06:08 (`#864 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/864>`_)
* micro-ROS rolling Library auto-update 10-04-2023 06:08 (`#862 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/862>`_)
* micro-ROS rolling Library auto-update 09-04-2023 06:07 (`#858 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/858>`_)
* micro-ROS rolling Library auto-update 05-04-2023 06:08 (`#857 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/857>`_)
* micro-ROS rolling Library auto-update 04-04-2023 06:24 (`#856 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/856>`_)
* micro-ROS rolling Library auto-update 31-03-2023 06:08 (`#854 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/854>`_)
* micro-ROS rolling Library auto-update 30-03-2023 06:08 (`#853 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/853>`_)
* micro-ROS rolling Library auto-update 29-03-2023 06:08 (`#849 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/849>`_)
* micro-ROS rolling Library auto-update 28-03-2023 06:08 (`#848 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/848>`_)
* micro-ROS rolling Library auto-update 27-03-2023 06:09 (`#847 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/847>`_)
* micro-ROS rolling Library auto-update 25-03-2023 06:07 (`#846 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/846>`_)
* micro-ROS rolling Library auto-update 24-03-2023 06:08 (`#845 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/845>`_)
* micro-ROS rolling Library auto-update 23-03-2023 06:08 (`#842 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/842>`_)
* micro-ROS rolling Library auto-update 22-03-2023 06:08 (`#840 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/840>`_)
* micro-commit of a comma as thanks for microROS (`#834 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/834>`_) (`#836 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/836>`_)
* micro-ROS rolling Library auto-update 21-03-2023 06:08 (`#835 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/835>`_)
* micro-ROS rolling Library auto-update 17-03-2023 06:07 (`#832 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/832>`_)
* micro-ROS rolling Library auto-update 16-03-2023 06:08 (`#828 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/828>`_)
* micro-ROS rolling Library auto-update 10-03-2023 06:09 (`#826 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/826>`_)
* micro-ROS rolling Library auto-update 09-03-2023 06:09 (`#822 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/822>`_)
* micro-ROS rolling Library auto-update 08-03-2023 06:09 (`#819 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/819>`_)
* micro-ROS rolling Library auto-update 07-03-2023 06:08 (`#815 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/815>`_)
* micro-ROS rolling Library auto-update 04-03-2023 06:08 (`#810 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/810>`_)
* micro-ROS rolling Library auto-update 03-03-2023 06:09 (`#804 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/804>`_)
* micro-ROS rolling Library auto-update 01-03-2023 06:09 (`#803 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/803>`_)
* micro-ROS rolling Library auto-update 28-02-2023 06:09 (`#802 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/802>`_)
* micro-ROS rolling Library auto-update 25-02-2023 06:07 (`#801 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/801>`_)
* micro-ROS rolling Library auto-update 24-02-2023 06:09 (`#797 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/797>`_)
* micro-ROS rolling Library auto-update 23-02-2023 06:08 (`#796 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/796>`_)
* micro-ROS rolling Library auto-update 18-02-2023 06:07 (`#792 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/792>`_)
* micro-ROS rolling Library auto-update 17-02-2023 06:09 (`#784 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/784>`_)
* Update README with new arm-none-eabi-gcc version (`#781 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/781>`_)
* micro-ROS rolling Library auto-update 09-02-2023 06:09 (`#780 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/780>`_)
* micro-ROS rolling Library auto-update 08-02-2023 06:09 (`#776 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/776>`_)
* micro-ROS rolling Library auto-update 07-02-2023 06:08 (`#774 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/774>`_)
* micro-ROS rolling Library auto-update 04-02-2023 06:07 (`#771 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/771>`_)
* micro-ROS rolling Library auto-update 02-02-2023 06:08 (`#769 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/769>`_)
* micro-ROS rolling Library auto-update 01-02-2023 06:09 (`#768 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/768>`_)
* micro-ROS rolling Library auto-update 31-01-2023 06:08 (`#766 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/766>`_)
* micro-ROS rolling Library auto-update 27-01-2023 06:08 (`#763 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/763>`_)
* micro-ROS rolling Library auto-update 24-01-2023 06:08 (`#759 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/759>`_)
* micro-ROS rolling Library auto-update 20-01-2023 06:08 (`#755 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/755>`_)
* micro-ROS rolling Library auto-update 19-01-2023 06:08 (`#752 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/752>`_)
* micro-ROS rolling Library auto-update 18-01-2023 06:08 (`#751 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/751>`_)
* micro-ROS rolling Library auto-update 17-01-2023 06:08 (`#750 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/750>`_)
* micro-ROS rolling Library auto-update 13-01-2023 06:08 (`#748 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/748>`_)
* micro-ROS rolling Library auto-update 06-01-2023 06:08 (`#743 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/743>`_)
* micro-ROS rolling Library auto-update 05-01-2023 06:07 (`#742 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/742>`_)
* micro-ROS rolling Library auto-update 04-01-2023 06:08 (`#741 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/741>`_)
* micro-ROS rolling Library auto-update 21-12-2022 06:08 (`#739 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/739>`_)
* micro-ROS rolling Library auto-update 16-12-2022 06:08 (`#738 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/738>`_)
* micro-ROS rolling Library auto-update 13-12-2022 06:08 (`#732 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/732>`_)
* micro-ROS rolling Library auto-update 09-12-2022 06:08 (`#730 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/730>`_)
* micro-ROS rolling Library auto-update 07-12-2022 06:08 (`#729 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/729>`_)
* micro-ROS rolling Library auto-update 06-12-2022 06:08 (`#727 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/727>`_)
* micro-ROS rolling Library auto-update 01-12-2022 06:09 (`#725 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/725>`_)
* micro-ROS rolling Library auto-update 30-11-2022 06:09 (`#724 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/724>`_)
* micro-ROS rolling Library auto-update 29-11-2022 06:08 (`#723 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/723>`_)
* micro-ROS rolling Library auto-update 25-11-2022 06:09 (`#721 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/721>`_)
* micro-ROS rolling Library auto-update 24-11-2022 06:09 (`#718 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/718>`_)
* micro-ROS rolling Library auto-update 22-11-2022 06:09 (`#714 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/714>`_)
* micro-ROS rolling Library auto-update 19-11-2022 06:08 (`#711 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/711>`_)
* micro-ROS rolling Library auto-update 18-11-2022 06:09 (`#710 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/710>`_)
* micro-ROS rolling Library auto-update 17-11-2022 06:09 (`#709 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/709>`_)
* micro-ROS rolling Library auto-update 16-11-2022 06:09 (`#708 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/708>`_)
* micro-ROS rolling Library auto-update 11-11-2022 06:10 (`#705 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/705>`_)
* micro-ROS rolling Library auto-update 10-11-2022 06:10 (`#703 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/703>`_)
* micro-ROS rolling Library auto-update 05-11-2022 06:09 (`#700 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/700>`_)
* micro-ROS rolling Library auto-update 04-11-2022 06:09 (`#699 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/699>`_)
* micro-ROS rolling Library auto-update 03-11-2022 06:10 (`#698 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/698>`_)
* micro-ROS rolling Library auto-update 02-11-2022 06:14 (`#697 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/697>`_)
* micro-ROS rolling Library auto-update 27-10-2022 06:10 (`#694 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/694>`_)
* micro-ROS rolling Library auto-update 26-10-2022 06:10 (`#693 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/693>`_)
* micro-ROS rolling Library auto-update 25-10-2022 06:46 (`#692 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/692>`_)
* micro-ROS rolling Library auto-update 23-10-2022 06:19 (`#691 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/691>`_)
* micro-ROS rolling Library auto-update 21-10-2022 06:23 (`#689 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/689>`_)
* micro-ROS rolling Library auto-update 19-10-2022 06:52 (`#687 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/687>`_)
* micro-ROS rolling Library auto-update 18-10-2022 06:48 (`#683 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/683>`_)
* micro-ROS rolling Library auto-update 17-10-2022 06:44 (`#681 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/681>`_)
* micro-ROS rolling Library auto-update 14-10-2022 06:40 (`#676 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/676>`_)
* micro-ROS rolling Library auto-update 11-10-2022 06:32 (`#674 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/674>`_)
* micro-ROS rolling Library auto-update 05-10-2022 06:24 (`#673 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/673>`_)
* micro-ROS rolling Library auto-update 04-10-2022 06:20 (`#672 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/672>`_)
* micro-ROS rolling Library auto-update 03-10-2022 06:20 (`#669 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/669>`_)
* micro-ROS rolling Library auto-update 30-09-2022 06:43 (`#668 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/668>`_)
* micro-ROS rolling Library auto-update 27-09-2022 06:40 (`#663 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/663>`_)
* micro-ROS rolling Library auto-update 21-09-2022 06:43 (`#657 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/657>`_)
* micro-ROS rolling Library auto-update 14-09-2022 06:42 (`#656 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/656>`_)
* micro-ROS rolling Library auto-update 10-09-2022 06:17 (`#655 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/655>`_)
* micro-ROS rolling Library auto-update 09-09-2022 06:24 (`#653 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/653>`_)
* micro-ROS rolling Library auto-update 08-09-2022 06:36 (`#652 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/652>`_)
* micro-ROS rolling Library auto-update 06-09-2022 06:50 (`#650 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/650>`_)
* micro-ROS rolling Library auto-update 05-09-2022 06:43 (`#649 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/649>`_)
* micro-ROS rolling Library auto-update 04-09-2022 06:08 (`#648 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/648>`_)
* micro-ROS rolling Library auto-update 01-09-2022 06:21 (`#647 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/647>`_)
* micro-ROS rolling Library auto-update 24-08-2022 08:46 (`#644 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/644>`_)
* Update branch name (`#643 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/643>`_)
* micro-ROS rolling Library auto-update 24-08-2022 06:11 (`#641 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/641>`_)
* micro-ROS rolling Library auto-update 12-08-2022 06:09 (`#638 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/638>`_)
* micro-ROS rolling Library auto-update 11-08-2022 06:09 (`#636 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/636>`_)
* micro-ROS rolling Library auto-update 10-08-2022 06:06 (`#634 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/634>`_)
* micro-ROS rolling Library auto-update 09-08-2022 06:09 (`#631 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/631>`_)
* micro-ROS rolling Library auto-update 06-08-2022 06:08 (`#629 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/629>`_)
* micro-ROS rolling Library auto-update 04-08-2022 06:09 (`#626 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/626>`_)
* micro-ROS rolling Library auto-update 01-08-2022 06:23 (`#622 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/622>`_)
* micro-ROS rolling Library auto-update 31-07-2022 06:08 (`#621 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/621>`_)
* micro-ROS rolling Library auto-update 29-07-2022 06:09 (`#620 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/620>`_)
* micro-ROS rolling Library auto-update 27-07-2022 06:08 (`#619 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/619>`_)
* micro-ROS rolling Library auto-update 21-07-2022 06:09 (`#615 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/615>`_)
* micro-ROS rolling Library auto-update 20-07-2022 06:10 (`#611 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/611>`_)
* micro-ROS rolling Library auto-update 19-07-2022 06:13 (`#608 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/608>`_)
* micro-ROS rolling Library auto-update 18-07-2022 06:09 (`#606 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/606>`_)
* micro-ROS rolling Library auto-update 15-07-2022 06:09 (`#604 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/604>`_)
* micro-ROS rolling Library auto-update 13-07-2022 06:11 (`#601 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/601>`_)
* micro-ROS rolling Library auto-update 10-07-2022 06:08 (`#595 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/595>`_)
* micro-ROS rolling Library auto-update 01-07-2022 06:09 (`#591 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/591>`_)
* micro-ROS rolling Library auto-update 29-06-2022 06:08 (`#590 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/590>`_)
* micro-ROS rolling Library auto-update 26-06-2022 06:07 (`#588 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/588>`_)
* micro-ROS rolling Library auto-update 23-06-2022 06:08 (`#583 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/583>`_)
* micro-ROS rolling Library auto-update 20-06-2022 06:11 (`#581 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/581>`_)
* micro-ROS rolling Library auto-update 19-06-2022 06:08 (`#579 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/579>`_)
* micro-ROS rolling Library auto-update 16-06-2022 06:08 (`#574 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/574>`_)
* micro-ROS rolling Library auto-update 15-06-2022 06:08 (`#572 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/572>`_)
* micro-ROS rolling Library auto-update 14-06-2022 06:09 (`#571 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/571>`_)
* micro-ROS rolling Library auto-update 13-06-2022 06:09 (`#569 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/569>`_)
* micro-ROS rolling Library auto-update 12-06-2022 06:09 (`#566 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/566>`_)
* micro-ROS rolling Library auto-update 10-06-2022 06:08 (`#564 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/564>`_)
* micro-ROS rolling Library auto-update 09-06-2022 06:08 (`#563 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/563>`_)
* micro-ROS rolling Library auto-update 07-06-2022 06:08 (`#562 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/562>`_)
* micro-ROS rolling Library auto-update 06-06-2022 06:09 (`#561 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/561>`_)
* micro-ROS rolling Library auto-update 05-06-2022 06:07 (`#559 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/559>`_)
* micro-ROS rolling Library auto-update 03-06-2022 06:08 (`#555 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/555>`_)
* micro-ROS rolling Library auto-update 02-06-2022 06:14 (`#553 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/553>`_)
* micro-ROS rolling Library auto-update 01-06-2022 06:15 (`#550 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/550>`_)
* micro-ROS rolling Library auto-update 31-05-2022 06:09 (`#545 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/545>`_)
* micro-ROS rolling Library auto-update 27-05-2022 06:10 (`#542 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/542>`_)
* micro-ROS rolling Library auto-update 26-05-2022 06:09 (`#540 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/540>`_)

4.0.0 (2022-05-25)
------------------
* micro-ROS rolling Library auto-update 25-05-2022 06:09 (`#536 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/536>`_)
* micro-ROS rolling Library auto-update 24-05-2022 07:54 (`#534 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/534>`_)
* micro-ROS rolling Library auto-update 23-05-2022 06:12 (`#530 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/530>`_)
* micro-ROS rolling Library auto-update 22-05-2022 06:08 (`#528 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/528>`_)
* micro-ROS rolling Library auto-update 20-05-2022 06:09 (`#527 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/527>`_)
* micro-ROS rolling Library auto-update 19-05-2022 06:09 (`#525 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/525>`_)
* micro-ROS rolling Library auto-update 18-05-2022 06:10 (`#522 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/522>`_)
* micro-ROS rolling Library auto-update 17-05-2022 06:10 (`#519 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/519>`_)
* micro-ROS rolling Library auto-update 13-05-2022 06:15 (`#517 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/517>`_)
* micro-ROS rolling Library auto-update 12-05-2022 06:10 (`#514 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/514>`_)
* micro-ROS rolling Library auto-update 10-05-2022 06:09 (`#512 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/512>`_)
* micro-ROS rolling Library auto-update 09-05-2022 06:09 (`#510 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/510>`_)
* micro-ROS rolling Library auto-update 04-05-2022 06:10 (`#509 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/509>`_)
* micro-ROS rolling Library auto-update 03-05-2022 06:09 (`#508 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/508>`_)
* micro-ROS rolling Library auto-update 29-04-2022 07:07 (`#507 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/507>`_)
* Sort built packages (`#502 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/502>`_)
* micro-ROS rolling Library auto-update 29-04-2022 06:09 (`#501 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/501>`_)
* micro-ROS rolling Library auto-update 28-04-2022 06:11 (`#488 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/488>`_)
* Update banner (`#490 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/490>`_)
* micro-ROS rolling Library auto-update 20-04-2022 06:09 (`#487 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/487>`_)
* micro-ROS rolling Library auto-update 19-04-2022 06:09 (`#486 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/486>`_)
* micro-ROS rolling Library auto-update 18-04-2022 06:10 (`#485 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/485>`_)
* micro-ROS rolling Library auto-update 17-04-2022 06:08 (`#483 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/483>`_)
* micro-ROS rolling Library auto-update 13-04-2022 06:09 (`#481 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/481>`_)
* micro-ROS rolling Library auto-update 12-04-2022 06:08 (`#480 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/480>`_)
* micro-ROS rolling Library auto-update 11-04-2022 06:09 (`#479 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/479>`_)
* micro-ROS rolling Library auto-update 10-04-2022 06:08 (`#478 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/478>`_)
* micro-ROS rolling Library auto-update 08-04-2022 06:08 (`#474 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/474>`_)
* micro-ROS rolling Library auto-update 07-04-2022 06:08 (`#472 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/472>`_)
* micro-ROS rolling Library auto-update 06-04-2022 06:08 (`#471 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/471>`_)
* micro-ROS rolling Library auto-update 05-04-2022 06:08 (`#470 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/470>`_)
* micro-ROS rolling Library auto-update 04-04-2022 06:09 (`#466 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/466>`_)
* micro-ROS rolling Library auto-update 03-04-2022 06:07 (`#465 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/465>`_)
* micro-ROS rolling Library auto-update 01-04-2022 06:09 (`#464 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/464>`_)
* Add logo (`#459 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/459>`_)
* micro-ROS rolling Library auto-update 31-03-2022 06:08 (`#458 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/458>`_)
* micro-ROS rolling Library auto-update 30-03-2022 06:08 (`#457 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/457>`_)
* micro-ROS rolling Library auto-update 29-03-2022 12:16 (`#455 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/455>`_)
* Fix Rolling includes (`#456 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/456>`_)
* micro-ROS rolling Library auto-update 26-03-2022 06:07 (`#453 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/453>`_)
* micro-ROS rolling Library auto-update 23-03-2022 06:09 (`#447 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/447>`_)
* micro-ROS rolling Library auto-update 22-03-2022 06:08 (`#445 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/445>`_)
* micro-ROS rolling Library auto-update 19-03-2022 06:07 (`#444 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/444>`_)
* micro-ROS rolling Library auto-update 17-03-2022 06:08 (`#443 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/443>`_)
* micro-ROS rolling Library auto-update 16-03-2022 06:09 (`#441 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/441>`_)
* micro-ROS rolling Library auto-update 15-03-2022 06:08 (`#440 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/440>`_)
* micro-ROS rolling Library auto-update 12-03-2022 06:07 (`#438 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/438>`_)
* micro-ROS rolling Library auto-update 11-03-2022 06:08 (`#437 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/437>`_)
* micro-ROS rolling Library auto-update 10-03-2022 06:08 (`#434 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/434>`_)
* micro-ROS rolling Library auto-update 09-03-2022 06:10 (`#433 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/433>`_)
* micro-ROS rolling Library auto-update 07-03-2022 06:09 (`#430 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/430>`_)
* micro-ROS rolling Library auto-update 04-03-2022 06:08 (`#427 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/427>`_)
* micro-ROS rolling Library auto-update 03-03-2022 06:08 (`#423 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/423>`_)
* micro-ROS rolling Library auto-update 02-03-2022 06:11 (`#422 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/422>`_)
* micro-ROS rolling Library auto-update 01-03-2022 06:11 (`#421 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/421>`_)
* micro-ROS rolling Library auto-update 26-02-2022 06:07 (`#420 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/420>`_)
* micro-ROS rolling Library auto-update 25-02-2022 06:08 (`#419 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/419>`_)
* micro-ROS rolling Library auto-update 24-02-2022 06:07 (`#418 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/418>`_)
* micro-ROS rolling Library auto-update 23-02-2022 06:08 (`#417 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/417>`_)
* micro-ROS rolling Library auto-update 22-02-2022 06:07 (`#416 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/416>`_)
* Update README.md (`#413 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/413>`_) (`#415 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/415>`_)
* micro-ROS rolling Library auto-update 21-02-2022 06:08 (`#411 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/411>`_)
* micro-ROS rolling Library auto-update 18-02-2022 06:08 (`#410 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/410>`_)
* micro-ROS rolling Library auto-update 17-02-2022 06:07 (`#409 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/409>`_)
* micro-ROS rolling Library auto-update 16-02-2022 06:06 (`#408 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/408>`_)
* micro-ROS rolling Library auto-update 15-02-2022 06:06 (`#407 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/407>`_)
* micro-ROS rolling Library auto-update 13-02-2022 06:07 (`#405 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/405>`_)
* micro-ROS rolling Library auto-update 11-02-2022 08:31 (`#403 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/403>`_)
* Fix include paths
* micro-ROS rolling Library auto-update 09-02-2022 06:08 (`#402 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/402>`_)
* micro-ROS rolling Library auto-update 08-02-2022 10:19 (`#399 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/399>`_)
* micro-ROS Library auto-update 08-02-2022 10:02 (`#398 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/398>`_)
* Fix include paths (`#396 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/396>`_)
* micro-ROS rolling Library auto-update 04-02-2022 06:05 (`#390 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/390>`_)
* micro-ROS rolling Library auto-update 03-02-2022 06:06 (`#389 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/389>`_)
* micro-ROS rolling Library auto-update 02-02-2022 06:07 (`#388 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/388>`_)
* micro-ROS rolling Library auto-update 01-02-2022 06:08 (`#386 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/386>`_)
* micro-ROS rolling Library auto-update 29-01-2022 06:07 (`#383 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/383>`_)
* micro-ROS rolling Library auto-update 28-01-2022 06:07 (`#382 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/382>`_)
* micro-ROS rolling Library auto-update 27-01-2022 06:06 (`#379 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/379>`_)
* micro-ROS rolling Library auto-update 26-01-2022 06:07 (`#378 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/378>`_)
* micro-ROS rolling Library auto-update 25-01-2022 06:07 (`#375 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/375>`_)
* micro-ROS rolling Library auto-update 23-01-2022 06:07 (`#372 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/372>`_)
* micro-ROS rolling Library auto-update 21-01-2022 06:08 (`#370 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/370>`_)
* micro-ROS rolling Library auto-update 19-01-2022 06:06 (`#369 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/369>`_)
* micro-ROS rolling Library auto-update 18-01-2022 06:07 (`#367 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/367>`_)
* micro-ROS rolling Library auto-update 15-01-2022 06:06 (`#366 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/366>`_)
* micro-ROS rolling Library auto-update 14-01-2022 06:07 (`#364 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/364>`_)
* micro-ROS rolling Library auto-update 13-01-2022 06:07 (`#361 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/361>`_)
* micro-ROS rolling Library auto-update 12-01-2022 06:07 (`#358 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/358>`_)
* micro-ROS rolling Library auto-update 11-01-2022 06:07 (`#355 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/355>`_)
* micro-ROS rolling Library auto-update 08-01-2022 06:06 (`#354 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/354>`_)
* micro-ROS rolling Library auto-update 06-01-2022 06:07 (`#352 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/352>`_)
* micro-ROS rolling Library auto-update 05-01-2022 06:07 (`#351 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/351>`_)
* micro-ROS rolling Library auto-update 24-12-2021 06:07 (`#349 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/349>`_)
* micro-ROS rolling Library auto-update 22-12-2021 06:07 (`#346 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/346>`_)
* micro-ROS rolling Library auto-update 21-12-2021 06:07 (`#344 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/344>`_)
* micro-ROS rolling Library auto-update 16-12-2021 06:06 (`#337 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/337>`_)
* micro-ROS rolling Library auto-update 15-12-2021 06:06 (`#335 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/335>`_)
* micro-ROS rolling Library auto-update 14-12-2021 06:06 (`#332 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/332>`_)
* micro-ROS rolling Library auto-update 11-12-2021 06:06 (`#328 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/328>`_)
* micro-ROS rolling Library auto-update 10-12-2021 06:06 (`#326 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/326>`_)
* micro-ROS rolling Library auto-update 09-12-2021 06:06 (`#322 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/322>`_)
* micro-ROS rolling Library auto-update 03-12-2021 06:06 (`#321 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/321>`_)
* micro-ROS rolling Library auto-update 02-12-2021 06:06 (`#318 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/318>`_)
* micro-ROS rolling Library auto-update 01-12-2021 06:06 (`#315 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/315>`_)
* micro-ROS rolling Library auto-update 30-11-2021 06:06 (`#312 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/312>`_)
* micro-ROS rolling Library auto-update 27-11-2021 06:06 (`#306 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/306>`_)
* micro-ROS rolling Library auto-update 26-11-2021 06:06 (`#303 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/303>`_)
* micro-ROS rolling Library auto-update 25-11-2021 06:08 (`#301 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/301>`_)
* micro-ROS rolling Library auto-update 24-11-2021 06:08 (`#300 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/300>`_)
* micro-ROS rolling Library auto-update 23-11-2021 06:06 (`#298 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/298>`_)
* micro-ROS rolling Library auto-update 22-11-2021 06:06 (`#296 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/296>`_)
* micro-ROS rolling Library auto-update 19-11-2021 06:06 (`#293 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/293>`_)
* micro-ROS rolling Library auto-update 18-11-2021 06:06 (`#290 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/290>`_)
* micro-ROS rolling Library auto-update 17-11-2021 06:06 (`#286 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/286>`_)
* micro-ROS rolling Library auto-update 16-11-2021 06:06 (`#284 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/284>`_)
* micro-ROS rolling Library auto-update 13-11-2021 06:06 (`#281 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/281>`_)
* micro-ROS rolling Library auto-update 12-11-2021 06:06 (`#280 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/280>`_)
* micro-ROS rolling Library auto-update 11-11-2021 06:06 (`#278 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/278>`_)
* micro-ROS rolling Library auto-update 10-11-2021 06:06 (`#274 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/274>`_)
* micro-ROS rolling Library auto-update 05-11-2021 06:06 (`#273 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/273>`_)
* micro-ROS rolling Library auto-update 04-11-2021 06:06 (`#270 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/270>`_)
* micro-ROS rolling Library auto-update 03-11-2021 06:06 (`#267 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/267>`_)
* micro-ROS rolling Library auto-update 02-11-2021 06:06 (`#264 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/264>`_)
* micro-ROS rolling Library auto-update 29-10-2021 06:07 (`#261 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/261>`_)
* micro-ROS rolling Library auto-update 27-10-2021 06:06 (`#260 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/260>`_)
* micro-ROS rolling Library auto-update 23-10-2021 06:06 (`#259 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/259>`_)
* micro-ROS rolling Library auto-update 21-10-2021 06:06 (`#258 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/258>`_)
* micro-ROS rolling Library auto-update 20-10-2021 06:06 (`#256 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/256>`_)
* micro-ROS rolling Library auto-update 16-10-2021 06:05 (`#254 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/254>`_)
* micro-ROS rolling Library auto-update 15-10-2021 06:06 (`#251 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/251>`_)
* micro-ROS rolling Library auto-update 14-10-2021 06:06 (`#248 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/248>`_)
* micro-ROS rolling Library auto-update 12-10-2021 06:06 (`#247 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/247>`_)
* micro-ROS rolling Library auto-update 11-10-2021 06:06 (`#244 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/244>`_)
* micro-ROS rolling Library auto-update 08-10-2021 06:07 (`#242 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/242>`_)
* micro-ROS rolling Library auto-update 04-10-2021 06:06 (`#239 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/239>`_)
* micro-ROS rolling Library auto-update 02-10-2021 06:07 (`#238 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/238>`_)
* micro-ROS rolling Library auto-update 01-10-2021 06:07 (`#237 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/237>`_)
* micro-ROS rolling Library auto-update 30-09-2021 06:06 (`#236 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/236>`_)
* micro-ROS rolling Library auto-update 29-09-2021 06:06 (`#235 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/235>`_)
* micro-ROS rolling Library auto-update 28-09-2021 06:06 (`#232 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/232>`_)
* micro-ROS rolling Library auto-update 23-09-2021 06:06 (`#229 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/229>`_)
* micro-ROS rolling Library auto-update 22-09-2021 06:06 (`#227 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/227>`_)
* micro-ROS rolling Library auto-update 20-09-2021 06:06 (`#226 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/226>`_)
* micro-ROS rolling Library auto-update 18-09-2021 06:05 (`#225 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/225>`_)
* micro-ROS rolling Library auto-update 17-09-2021 06:05 (`#224 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/224>`_)
* micro-ROS rolling Library auto-update 16-09-2021 06:06 (`#220 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/220>`_)
* micro-ROS rolling Library auto-update 14-09-2021 06:10 (`#217 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/217>`_)
* micro-ROS rolling Library auto-update 08-09-2021 06:05 (`#214 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/214>`_)
* micro-ROS rolling Library auto-update 07-09-2021 06:05 (`#211 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/211>`_)
* micro-ROS rolling Library auto-update 04-09-2021 06:05 (`#208 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/208>`_)
* micro-ROS rolling Library auto-update 03-09-2021 06:06 (`#207 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/207>`_)
* micro-ROS rolling Library auto-update 01-09-2021 06:10 (`#204 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/204>`_)
* micro-ROS rolling Library auto-update 31-08-2021 06:07 (`#201 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/201>`_)
* micro-ROS rolling Library auto-update 27-08-2021 06:07 (`#199 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/199>`_)
* micro-ROS rolling Library auto-update 26-08-2021 06:05 (`#198 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/198>`_)
* micro-ROS rolling Library auto-update 25-08-2021 06:10 (`#197 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/197>`_)
* micro-ROS rolling Library auto-update 24-08-2021 06:05 (`#196 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/196>`_)
* micro-ROS rolling Library auto-update 21-08-2021 06:04 (`#192 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/192>`_)
* micro-ROS rolling Library auto-update 13-08-2021 06:06 (`#190 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/190>`_)
* micro-ROS rolling Library auto-update 12-08-2021 06:05 (`#185 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/185>`_)
* micro-ROS rolling Library auto-update 11-08-2021 06:05 (`#184 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/184>`_)
* micro-ROS rolling Library auto-update 10-08-2021 06:05 (`#183 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/183>`_)
* micro-ROS rolling Library auto-update 09-08-2021 06:05 (`#182 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/182>`_)
* micro-ROS rolling Library auto-update 07-08-2021 06:04 (`#181 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/181>`_)
* micro-ROS rolling Library auto-update 30-07-2021 06:05 (`#179 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/179>`_)
* micro-ROS rolling Library auto-update 29-07-2021 06:06 (`#175 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/175>`_)
* micro-ROS rolling Library auto-update 27-07-2021 06:05 (`#172 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/172>`_)
* micro-ROS rolling Library auto-update 23-07-2021 06:04 (`#170 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/170>`_)
* micro-ROS rolling Library auto-update 22-07-2021 06:05 (`#169 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/169>`_)
* micro-ROS rolling Library auto-update 21-07-2021 06:05 (`#167 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/167>`_)
* micro-ROS rolling Library auto-update 20-07-2021 06:04 (`#165 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/165>`_)
* micro-ROS rolling Library auto-update 18-07-2021 06:04 (`#161 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/161>`_)
* micro-ROS rolling Library auto-update 16-07-2021 06:04 (`#159 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/159>`_)
* micro-ROS rolling Library auto-update 15-07-2021 06:05 (`#156 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/156>`_)
* micro-ROS rolling Library auto-update 14-07-2021 06:05 (`#153 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/153>`_)
* micro-ROS rolling Library auto-update 13-07-2021 06:04 (`#151 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/151>`_)
* micro-ROS rolling Library auto-update 11-07-2021 06:04 (`#148 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/148>`_)
* micro-ROS rolling Library auto-update 08-07-2021 06:04 (`#146 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/146>`_)
* micro-ROS rolling Library auto-update 07-07-2021 06:03 (`#144 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/144>`_)
* micro-ROS rolling Library auto-update 06-07-2021 06:04 (`#143 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/143>`_)
* micro-ROS rolling Library auto-update 03-07-2021 06:05 (`#138 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/138>`_)
* micro-ROS rolling Library auto-update 02-07-2021 06:07 (`#137 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/137>`_)
* micro-ROS rolling Library auto-update 01-07-2021 06:04 (`#134 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/134>`_)
* micro-ROS rolling Library auto-update 30-06-2021 06:05 (`#132 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/132>`_)
* micro-ROS rolling Library auto-update 26-06-2021 06:04 (`#127 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/127>`_)
* micro-ROS rolling Library auto-update 25-06-2021 06:03 (`#125 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/125>`_)
* micro-ROS rolling Library auto-update 24-06-2021 06:02 (`#123 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/123>`_)
* micro-ROS rolling Library auto-update 19-06-2021 06:04 (`#122 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/122>`_)
* micro-ROS rolling Library auto-update 18-06-2021 06:04 (`#119 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/119>`_)
* micro-ROS rolling Library auto-update 17-06-2021 06:04 (`#117 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/117>`_)
* micro-ROS rolling Library auto-update 16-06-2021 06:05 (`#114 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/114>`_)
* micro-ROS rolling Library auto-update 15-06-2021 06:05 (`#112 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/112>`_)
* micro-ROS rolling Library auto-update 14-06-2021 06:05 (`#111 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/111>`_)
* micro-ROS rolling Library auto-update 12-06-2021 06:04 (`#109 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/109>`_)
* micro-ROS rolling Library auto-update 11-06-2021 06:05 (`#107 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/107>`_)
* micro-ROS rolling Library auto-update 10-06-2021 06:11 (`#106 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/106>`_)
* micro-ROS rolling Library auto-update 05-06-2021 06:40 (`#104 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/104>`_)
* micro-ROS rolling Library auto-update 04-06-2021 07:37 (`#102 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/102>`_)
* micro-ROS rolling Library auto-update 03-06-2021 07:19 (`#99 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/99>`_)
* micro-ROS rolling Library auto-update 02-06-2021 09:42 (`#96 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/96>`_)
* micro-ROS rolling Library auto-update 01-06-2021 07:34 (`#93 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/93>`_)
* micro-ROS rolling Library auto-update 29-05-2021 07:19 (`#91 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/91>`_)
* micro-ROS rolling Library auto-update 26-05-2021 14:16 (`#86 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/86>`_)
* micro-ROS rolling Library auto-update 25-05-2021 06:18 (`#85 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/85>`_)
* micro-ROS rolling Library auto-update 22-05-2021 06:07 (`#82 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/82>`_)
* micro-ROS rolling Library auto-update 21-05-2021 06:07 (`#79 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/79>`_)
* Update main
* Update main
* Add Galactic (`#74 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/74>`_)
* micro-ROS rolling Library auto-update 20-05-2021 05:47 (`#73 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/73>`_)
* micro-ROS rolling Library auto-update 19-05-2021 06:07 (`#70 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/70>`_)
* micro-ROS rolling Library auto-update 18-05-2021 06:07 (`#68 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/68>`_)
* micro-ROS rolling Library auto-update 17-05-2021 06:07 (`#65 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/65>`_)
* micro-ROS rolling Library auto-update 14-05-2021 06:07 (`#64 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/64>`_)
* micro-ROS rolling Library auto-update 13-05-2021 06:07 (`#62 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/62>`_)
* micro-ROS rolling Library auto-update 12-05-2021 06:06 (`#61 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/61>`_)
* micro-ROS rolling Library auto-update 11-05-2021 06:04 (`#60 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/60>`_)
* micro-ROS rolling Library auto-update 08-05-2021 06:04 (`#57 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/57>`_)
* micro-ROS rolling Library auto-update 07-05-2021 06:04 (`#55 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/55>`_)
* micro-ROS rolling Library auto-update 06-05-2021 06:04 (`#53 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/53>`_)
* multichange tool (`#52 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/52>`_)
* micro-ROS rolling Library auto-update 05-05-2021 11:31 (`#50 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/50>`_)
* micro-ROS rolling Library auto-update 05-05-2021 06:19 (`#48 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/48>`_)
* micro-ROS rolling Library auto-update 04-05-2021 07:58 (`#45 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/45>`_)
* micro-ROS rolling Library auto-update 30-04-2021 10:33 (`#43 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/43>`_)
* micro-ROS rolling Library auto-update 30-04-2021 06:07 (`#41 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/41>`_)
* micro-ROS rolling Library auto-update 28-04-2021 06:12 (`#39 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/39>`_)
* micro-ROS rolling Library auto-update 27-04-2021 06:11 (`#37 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/37>`_)
* micro-ROS rolling Library auto-update 24-04-2021 06:11 (`#36 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/36>`_)
* Add compiler version to README (`#35 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/35>`_)
* micro-ROS rolling Library auto-update 23-04-2021 06:11 (`#32 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/32>`_)
* Add agent ping wait on example (`#31 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/31>`_)
* micro-ROS rolling Library auto-update 22-04-2021 06:11 (`#27 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/27>`_)
* micro-ROS rolling Library auto-update 21-04-2021 06:11 (`#24 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/24>`_)
* micro-ROS rolling Library auto-update 17-04-2021 06:11 (`#23 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/23>`_)
* micro-ROS rolling Library auto-update 16-04-2021 06:11 (`#22 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/22>`_)
* micro-ROS rolling Library auto-update 15-04-2021 06:11 (`#21 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/21>`_)
* micro-ROS rolling Library auto-update 14-04-2021 06:11 (`#19 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/19>`_)
* micro-ROS rolling Library auto-update 13-04-2021 06:11 (`#18 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/18>`_)
* micro-ROS rolling Library auto-update 12-04-2021 06:11 (`#16 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/16>`_)
* micro-ROS rolling Library auto-update 08-04-2021 06:11 (`#14 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/14>`_)
* Update
* Update
* Update library generation
* micro-ROS rolling Library auto-update 07-04-2021 06:11 (`#12 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/12>`_)
* micro-ROS rolling Library auto-update 06-04-2021 07:02 (`#11 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/11>`_)
* micro-ROS rolling Library auto-update 05-04-2021 07:41 (`#8 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/8>`_)
* Fix permissions
* Fix workflow
* Add automatic library generation (`#7 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/7>`_)
* Add micro-ros-agent Snap details (`#5 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/5>`_)
* Add CI (`#4 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/4>`_)
* Update README.md (`#3 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/3>`_)
* Update README.md
* Update licensing (`#1 <https://github.com/micro-ROS/micro_ros_raspberrypi_pico_sdk/issues/1>`_)
* Update README.md
* Update README.md
* Update README.md
* Update README.md
* Update README.md
* Update README.md
* Initial commit
